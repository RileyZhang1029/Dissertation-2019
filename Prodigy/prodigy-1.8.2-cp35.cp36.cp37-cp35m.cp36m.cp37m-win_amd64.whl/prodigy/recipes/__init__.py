# coding: utf8
from __future__ import unicode_literals

from . import dep, ner, textcat, pos, compare, terms, generic, image, review  # noqa
