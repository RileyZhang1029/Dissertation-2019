from typing import Optional

import jwt
from fastapi import HTTPException
from fastapi.security.http import HTTPAuthorizationCredentials, HTTPBearer
from jwt import PyJWTError
from pydantic import Schema, ValidationError
from starlette.requests import Request
from starlette.status import HTTP_403_FORBIDDEN

from .schemas import JWTPayload
from .shared import JWT_COOKIE_NAME


class JWTAuthorizationCredentials(HTTPAuthorizationCredentials):
    credentials: str = Schema(..., description="The source JWT token string")
    scheme: str = Schema("bearer", description="the HTTP authorization scheme")
    payload: JWTPayload = Schema(
        ..., description="the JSON payload extracted from the token"
    )


class JWTBearer(HTTPBearer):
    def __init__(
        self,
        jwt_secret: str = None,
        jwt_audience: str = None,
        jwt_algorithm: str = "HS256",
    ):
        super(JWTBearer, self).__init__()
        self.jwt_secret = jwt_secret
        self.jwt_audience = jwt_audience
        self.jwt_algorithm = jwt_algorithm

    async def __call__(self, request: Request) -> Optional[JWTAuthorizationCredentials]:
        # Extract auth token from httponly cookie if it's present.
        if JWT_COOKIE_NAME in request.cookies:
            auth = HTTPAuthorizationCredentials(
                scheme="bearer", credentials=request.cookies[JWT_COOKIE_NAME]
            )
        else:
            # If there isn't a cookie, fallback to Authorization header
            auth: HTTPAuthorizationCredentials = await super(JWTBearer, self).__call__(
                request
            )
        try:
            payload = jwt.decode(
                auth.credentials,
                self.jwt_secret,
                algorithms=[self.jwt_algorithm],
                audience=self.jwt_audience,
            )
        except (PyJWTError, ValidationError) as e:
            raise HTTPException(
                status_code=HTTP_403_FORBIDDEN, detail=f"Token Error: {e}"
            )
        return JWTPayload(**payload)
